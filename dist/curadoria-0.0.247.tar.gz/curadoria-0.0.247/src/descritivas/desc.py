from core 		 import core

def funcao():
	print("Sou uma função do módulo DESCRITIVA  v0.0.2")