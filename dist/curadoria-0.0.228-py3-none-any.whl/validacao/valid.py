
def funcao():
	print("Sou uma função do módulo VALIDACAO v0.0.2")