def info(msg):
	print(msg+"...")
